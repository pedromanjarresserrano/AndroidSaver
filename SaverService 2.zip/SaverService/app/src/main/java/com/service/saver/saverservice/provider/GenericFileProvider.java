package com.service.saver.saverservice.provider;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {}
