package com.service.saver.saverservice

import android.os.Bundle
import android.support.v7.app.AppCompatActivity


class FolderActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_folder)
    }
}
